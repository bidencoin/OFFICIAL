Development moved to https://gitlab.com/blacknet-ninja

https://bidencoin.org/ aims to continue on Bidencoin chain.
